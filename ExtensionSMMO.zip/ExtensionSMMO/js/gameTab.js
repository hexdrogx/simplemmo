var travelBtn, townBtn, arenaBtn, notificationsBtn, messagesBtn, guildsBtn, questsBtn, characterBtn, inventoryBtn, communityBtn, leaderboardsBtn, profileBtn, friendsBtn, storeBtn, preferencesBtn, aboutBtn, supportBtn;
var hpSpan = document.getElementById("hp");
var expSpan = document.getElementById("experience");
var energySpan = document.getElementById("energy");
var goldSpan = document.getElementById("gold");
var nameSpan = document.getElementById("name");
var diamondsSpan = document.getElementById("diamonds");
var levelSpan = document.getElementById("level");
var avatarSpan = document.getElementById("avatar");
var stepsSpan = document.getElementById("steps");
var expBar = document.getElementById("expBar");
var energyBar = document.getElementById("energyBar");
var hpBar = document.getElementById("hpBar");
var messages = document.getElementById("messages");
var messagesM = document.getElementById("messagesM");
var head = document.getElementsByTagName('head')[0]
var questSpan = document.getElementById("questPoints");
//var loader = document.getElementById("loader");
var wrapper = document.getElementById("wrapper");
var loading = document.getElementById("loading");
var sign = document.getElementById("sign");
var liveChat = document.getElementById("live-chat");
var questPointCount;
var myArr;
var check;
var urlC, xmlhttpC, myArrC;
var chat = document.getElementById('chat-history');
var chatArea = document.getElementById('chat-area');
var warning = document.getElementsByClassName('chat-feedback')[0];
var text = document.getElementById('chatText');
var updateBtn = document.getElementById('refresh');
var row = "<hr>";
var space = "<br />"
var container = document.createElement("div"); container.className  = "container";
var sendBtn = document.getElementById('send');
var state = true;
var autoUpdate;
var questsWikiBtn, helmetsWikiBtn, amuletsWikiBtn, armourWikiBtn, shieldsWikiBtn, weaponsWikiBtn, bootsWikiBtn, petsWikiBtn, booksWikiBtn, foodWikiBtn, collectiblesWikiBtn, homeWikiBtn, arenaWikiBtn;
var about = document.getElementById("aboutLink");
var game = document.getElementById("gameLink");
var agent, game_frame;
var startDateTime, startStamp, newDate, newStamp;

function updateChat(){
    console.log("Loading..")
    //loader.style.display = "block";
    xmlhttpC = new XMLHttpRequest();
    urlC = "http://simple-mmo.com/chatapi";
    xmlhttpC.open("GET", urlC, true);
    xmlhttpC.send();
    xmlhttpC.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            myArrC = JSON.parse(this.responseText);
        }
    };
    xmlhttpC.onload = function(){
      myArrC = JSON.parse(this.responseText);
      startDateTime = new Date();
      startStamp = startDateTime.getTime();
      setInterval(updateClock, 1000);
    }
}


function send(){
      try {
        var xhr = new XMLHttpRequest();
        xhr.open("POST", "http://simple-mmo.com/chat/submit", true);
        xhr.setRequestHeader('Content-Type', 'application/json');
        xhr.send(JSON.stringify({
          chattext: text.value
        }));
        text.value = "";
        warning.style.display = "none";

      } catch (e) {
        console.log("Something is wrong with sending.");
      }
}


function refresh(){
  try {
    //loader.style.display = "none";
    console.log("Updating chat..");
    chat.innerHTML = "";
    Object.keys(myArrC).forEach(function (item) {
    if(myArrC[item].online == ""){
      myArrC[item].online = '<span class="dot-offline"></span>';
    }
    if(myArrC[item].username.includes(myArr.username)){
      myArrC[item].username = '<span id="you">' + myArrC[item].username + '</span>';
    }
    var container = document.createElement("div"); container.className  = "chat-message clearfixr";
    var img = document.createElement("img"); img.alt = "Avatar"; img.src= 'http://simple-mmo.com/img/sprites/' + myArrC[item].avatar + '.png';
    var time = document.createElement("span"); time.className = "chat-time"; time.id = "time"; time.innerText = myArrC[item].created_at2;
    var by = document.createElement("h5"); by.id = "by"; by.innerHTML = '<a href="#" class=' + myArrC[item].userid + '>' + myArrC[item].username +'</a>';
    var message = document.createElement("p"); message.id = "message"; message.innerHTML = myArrC[item].text;
    var online = document.createElement("span"); online.id = "online"; online.innerHTML = myArrC[item].online;
    chat.appendChild(container);
    container.appendChild(img);
    container.appendChild(time);
    container.appendChild(online);
    container.appendChild(by);
    container.innerHTML += space;
    container.appendChild(message);
    container.innerHTML += row;
    var anchors = document.getElementsByClassName(myArrC[item].userid);
    for (var i = 0; i < anchors.length; i++) {
        anchors[i].addEventListener('click', function() {
          redirect(myArrC[item].userid);
        });
    }

    });
  }
  catch{
    console.log("Not loaded yet.")
    //loader.style.display = "block";
    setTimeout(function() {
      refresh();
    }, 600);
  }
}

function redirect(id){
  load();
  game_frame.src = "http://simple-mmo.com/user/view/" + id;
}


function updateClock() {
    newDate = new Date();
    newStamp = newDate.getTime();
    var diff = Math.round((newStamp-startStamp)/1000);

    var d = Math.floor(diff/(24*60*60));
    diff = diff-(d*24*60*60);
    var h = Math.floor(diff/(60*60));
    diff = diff-(h*60*60);
    var m = Math.floor(diff/(60));
    diff = diff-(m*60);
    var s = diff;

    document.getElementById("latest").innerHTML = "Updated ";

    if(d>0){
    	document.getElementById("latest").innerHTML += d + " days ago";
    }
    else if(h>0){
    	document.getElementById("latest").innerHTML += h + " hours ago";
    }
    else if(m>0){
    	document.getElementById("latest").innerHTML += m + " minutes ago";
    }
    else{
    	document.getElementById("latest").innerHTML += s + " seconds ago";
    }
}


function questPointsLoad(){
  try{
    $.get('http://simple-mmo.com/quests/viewall', null, function(text){
      questPointCount = $(text).find('#questPoints').text();
    });
    setTimeout(function() {
      questSpan.innerText = questPointCount;
    }, 600);
  }
    catch{
      setTimeout(function() {
        questPointsLoad();
      }, 600);
    }

}

(function() {

	$('.clearfix').on('click', function(e) {
    if($(e.target).is("button")) return;
		$('.chat').slideToggle(300, 'swing');
    if (state == false) {
      console.log("On");
      document.getElementById("latest").style.display = "inline-block";
      updateChat();
      setTimeout(function() {
        refresh();
      }, 600);
      autoUpdate = setInterval(function() {
        updateChat();
        setTimeout(function() {
          refresh();
        }, 600);
      }, 30000);
      state = true;
      return;
    }
    else if (state == true) {
      console.log("Off");
      clearInterval(autoUpdate);
      document.getElementById("latest").style.display = "none";
      state = false;
      return;
    }
	});
}) ();

function loadPlayer(){
    console.log("Loading..")
    xmlhttp = new XMLHttpRequest();
    url = "http://simple-mmo.com/mobapi";
    xmlhttp.open("GET", url, true);
    xmlhttp.send();
    xmlhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            myArr = JSON.parse(this.responseText);
        }
    };
    xmlhttp.onload = function(){
      myArr = JSON.parse(this.responseText);
    }
}




document.addEventListener('DOMContentLoaded', function() {
    game_frame = document.getElementById("game_frame");
    agent = navigator.userAgent + " | CHROME EXTENSION";
    game_frame.src = "http://simple-mmo.com/";
    travelBtn = document.getElementById("travelBtn");
    townBtn = document.getElementById("townBtn");
    arenaBtn = document.getElementById("arenaBtn");
    bossesBtn = document.getElementById("bossesBtn");
    notificationsBtn = document.getElementById("notificationsBtn");
    messagesBtn = document.getElementById("messagesBtn");
    guildsBtn = document.getElementById("guildsBtn");
    questsBtn = document.getElementById("questsBtn");
    characterBtn = document.getElementById("characterBtn");
    inventoryBtn = document.getElementById("inventoryBtn");
    leaderboardsBtn = document.getElementById("leaderboardsBtn");
    communityBtn = document.getElementById("communityBtn");
    friendsBtn = document.getElementById("friendsBtn");
    profileBtn = document.getElementById("profileBtn");
    storeBtn = document.getElementById("storeBtn");
    preferencesBtn = document.getElementById("preferencesBtn");
    aboutBtn = document.getElementById("aboutBtn");
    supportBtn = document.getElementById("supportBtn");

    supportBtn = document.getElementById("supportBtn");
    homeWikiBtn = document.getElementById("homeWikiBtn");
    questsWikiBtn = document.getElementById("questsWikiBtn");
    arenaWikiBtn = document.getElementById("arenaWikiBtn");
    regWikiBtn = document.getElementById("regWikiBtn");
    helmetsWikiBtn = document.getElementById("helmetsWikiBtn");
    amuletsWikiBtn = document.getElementById("amuletsWikiBtn");
    armourWikiBtn = document.getElementById("armourWikiBtn");
    shieldsWikiBtn = document.getElementById("shieldsWikiBtn");
    weaponsWikiBtn = document.getElementById("weaponsWikiBtn");
    bootsWikiBtn = document.getElementById("bootsWikiBtn");
    petsWikiBtn = document.getElementById("petsWikiBtn");
    booksWikiBtn = document.getElementById("booksWikiBtn");
    foodWikiBtn = document.getElementById("foodWikiBtn");
    collectiblesWikiBtn = document.getElementById("collectiblesWikiBtn");

    questsWikiBtn.addEventListener('click', function() {
        game_frame.src = 'https://simplemmo.fandom.com/wiki/List_of_Quests';
        load();
    });


    helmetsWikiBtn.addEventListener('click', function() {
        game_frame.src = 'https://simplemmo.fandom.com/wiki/List_of_Helmets';
        load();
    });

    amuletsWikiBtn.addEventListener('click', function() {
        game_frame.src =  'https://simplemmo.fandom.com/wiki/List_of_Amulets';
        load();
    });

    armourWikiBtn.addEventListener('click', function() {
        game_frame.src =  'https://simplemmo.fandom.com/wiki/List_of_Armour';
        load();
    });

    shieldsWikiBtn.addEventListener('click', function() {
        game_frame.src =  'https://simplemmo.fandom.com/wiki/List_of_Shields';
        load();
    });

    weaponsWikiBtn.addEventListener('click', function() {
       game_frame.src =  'https://simplemmo.fandom.com/wiki/List_of_Weapons';
       load();
    });

    bootsWikiBtn.addEventListener('click', function() {
        game_frame.src =  'https://simplemmo.fandom.com/wiki/List_of_Boots';
        load();
    });

    petsWikiBtn.addEventListener('click', function() {
        game_frame.src =  'https://simplemmo.fandom.com/wiki/List_of_Pets';
        load();
    });

    booksWikiBtn.addEventListener('click', function() {
        game_frame.src =  'https://simplemmo.fandom.com/wiki/List_of_Books';
        load();
    });

    foodWikiBtn.addEventListener('click', function() {
        game_frame.src =  'https://simplemmo.fandom.com/wiki/List_of_Food';
        load();
    });

    collectiblesWikiBtn.addEventListener('click', function() {
        game_frame.src =  'https://simplemmo.fandom.com/wiki/List_of_Collectibles';
        load();
    });

    homeWikiBtn.addEventListener('click', function() {
        game_frame.src =  'https://simplemmo.fandom.com/wiki/Home';
        load();
    });

    arenaWikiBtn.addEventListener('click', function() {
        game_frame.src =  'https://simplemmo.fandom.com/wiki/Battle_arena';
        load();
    });

    chatArea.addEventListener('submit', function() {
      if(text != ""){
          event.preventDefault();   //stop form from submitting
          send();
          setTimeout(function() {
            updateChat();
            setTimeout(function() {
              refresh();
            }, 300);
          }, 300);
          warning.style.display = "none";
      }
      else{
        warning.style.display = "block";
      }},
      false);



    sendBtn.addEventListener('click', function() {
      send();
      setTimeout(function() {
        updateChat();
        setTimeout(function() {
          refresh();
        }, 300);
      }, 600);
    });

    updateBtn.addEventListener('click', function() {
      updateChat();
      setTimeout(function() {
        refresh();
      }, 600);
    });

    travelBtn.addEventListener('click', function() {
      menu("travel");
    });

    townBtn.addEventListener('click', function() {
      menu("town");
    });

    arenaBtn.addEventListener('click', function() {
      menu("arena");
    });

    bossesBtn.addEventListener('click', function() {
      menu("bosses");
    });

    notificationsBtn.addEventListener('click', function() {
      menu("notifications");
    });

    messagesBtn.addEventListener('click', function() {
      menu("messages");
    });

    guildsBtn.addEventListener('click', function() {
      menu("guilds");
    });

    questsBtn.addEventListener('click', function() {
      menu("quests");
    });

    characterBtn.addEventListener('click', function() {
      menu("character");
    });

    inventoryBtn.addEventListener('click', function() {
      menu("inventory");
    });

    leaderboardsBtn.addEventListener('click', function() {
      menu("leaderboards");
    });

    communityBtn.addEventListener('click', function() {
      menu("community");
    });

    friendsBtn.addEventListener('click', function() {
      menu("friends");
    });

    profileBtn.addEventListener('click', function() {
      menu("profile");
    });

    nameSpan.addEventListener('click', function() {
      menu("profile");
    });

    storeBtn.addEventListener('click', function() {
      menu("store");
    });

    preferencesBtn.addEventListener('click', function() {
      menu("preferences");
    });

    aboutBtn.addEventListener('click', function() {
      menu("about");
    });

    supportBtn.addEventListener('click', function() {
      menu("support");
    });

    gameLink.addEventListener('click', function() {
      menu("game");
    });

    aboutLink.addEventListener('click', function() {
      menu("aboutEx");
    });

  });




  function menu(btn){
    switch (btn) {
      case "travel":
        load();
        game_frame.src = "http://simple-mmo.com/travel";
        break;

      case "town":
        load();
        game_frame.src = "http://simple-mmo.com/town";
        break;

      case "arena":
        load();
        game_frame.src = "http://simple-mmo.com/npcs/viewall";
        break;

      case "bosses":
        load();
        game_frame.src = "http://simple-mmo.com/worldbosses";
        break;

      case "notifications":
        load();
        game_frame.src = "http://simple-mmo.com/events";
        break;

      case "messages":
        load();
        game_frame.src = "http://simple-mmo.com/messages/inbox";
        break;

      case "guilds":
        load();
        game_frame.src = "http://simple-mmo.com/guilds/menu";
        break;

      case "quests":
        load();
        game_frame.src = "http://simple-mmo.com/quests/viewall";
        break;
      case "character":
        load();
        game_frame.src = "http://simple-mmo.com/user/character";
        break;

      case "inventory":
        load();
        game_frame.src = "http://simple-mmo.com/inventory";
        break;

      case "leaderboards":
        load();
        game_frame.src = "http://simple-mmo.com/leaderboards";
        break;

      case "community":
        load();
        game_frame.src = "http://simple-mmo.com/community";
        break;

      case "store":
        load();
        game_frame.src = "http://simple-mmo.com/diamondstore";
        break;

      case "friends":
        load();
        game_frame.src = "http://simple-mmo.com/friends";
        break;

      case "profile":
        load();
        game_frame.src = "http://simple-mmo.com/me";
        break;

      case "preferences":
        load();
        game_frame.src = "http://simple-mmo.com/preferences";
        break;

      case "about":
      load();
        game_frame.src = "http://simple-mmo.com/about";
        break;

      case "support":
      load();
        game_frame.src = "http://simple-mmo.com/support";
        break;

      case "aboutEx":
        load();
        game_frame.src = chrome.extension.getURL('about.html');
        break;

      case "game":
        load();
        game_frame.src = "http://simple-mmo.com/";
        break;

      default:
        load();
        game_frame.src = "http://simple-mmo.com/";
        break;
    }
  }

  function login(){
    try {
      check = myArr.loggedin;
    } catch
    {
      setTimeout(function() {
        login();
        loaded();
      }, 600);
    }

  }

  function update(){
    try{
      stepsSpan.innerText = myArr.stepsleft;
      avatarSpan.src = 'http://simple-mmo.com/img/sprites/' + myArr.avatar + '.png';
      nameSpan.innerText =  myArr.username;
      levelSpan.innerText =  myArr.level;
      energySpan.innerText = myArr.energy + " / " + myArr.max_energy;
      hpSpan.innerText = myArr.current_hp + " / " + myArr.max_hp;
      expSpan.innerText = myArr.exp + " / " + myArr.max_exp;
      goldSpan.innerText = myArr.gold;
      diamondsSpan.innerText = myArr.diamonds;
      expBar.value = myArr.exp_percent;
      hpBar.value = myArr.hp_percent;
      energyBar.value = myArr.energy_percent;
      messagesM.innerText = myArr.messages;
    }
    catch{
      setTimeout(function() {
        update();
      }, 600);
    }
  }


  chrome.webRequest.onBeforeSendHeaders.addListener(
      function(info) {
          // Replace the User-Agent header
          var headers = info.requestHeaders;
          headers.forEach(function(header, i) {
              if (header.name.toLowerCase() == 'user-agent') {
                  header.value = agent;
              }
          });
          return {requestHeaders: headers};
      },
      // Request filter
      {
          // Modify the headers for these pages
          urls: [
              "http://simple-mmo.com/*"
          ],
          // In the main window and frames
          types: ["main_frame", "sub_frame", "xmlhttprequest"]
      },
      ["blocking", "requestHeaders"]
  );


function checkTime(i) {
  if (i < 10) {
    i = "0" + i;
  }
  return i;
}
function startTime() {
  var today = new Date();
  var timer = document.getElementById('time');
  timer.innerHTML = today.toLocaleTimeString('en-GB', { timeZone: 'Europe/London' });
  t = setTimeout(function() {
    startTime()
  }, 500);
}

function loadChat(){
  refresh();
  updateChat();
}
function load(){
  questPointsLoad();
  loadPlayer();
}

function loaded(){
  if(check == "true"){
    loadChat();
    wrapper.style.display = "block";
    liveChat.style.display = "block";
    loading.style.display = "none";
    sign.style.display = "none";
    startTime();
    update();
    window.setInterval(function(){
      update();
    }, 100);
  }
  else{
    sign.style.display = "block";
    loading.style.display = "none";
    wrapper.style.display = "none";
    liveChat.style.display = "none";
  }

}

window.onload = function() {
  load();
  console.log("On");
  setTimeout(function() {
    login();
    loaded();
  }, 1200);

  $('#live-chat header').click();
}
